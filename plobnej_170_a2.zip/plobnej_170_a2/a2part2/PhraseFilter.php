<!DOCTYPE html>
<html>
<head>
    <title> PhraseFilter </title>
</head>
<body>
<?php
function determine_type_of_word($word) {
    $has_only_alphabetic_characters = true;
    $word = str_replace(' ', '', $word); 
    
    for ($i = 0; $i < strlen($word); $i++) {
        $char = $word[$i];
        if (!(($char >= 'a' && $char <= 'z') || ($char >= 'A' && $char <= 'Z'))) {
            $has_only_alphabetic_characters = false;
            break;
        }
    }

    if ($has_only_alphabetic_characters) {
        return 'alphabetic characters'; 
    } elseif (strpos($word, '.') !== false && is_numeric($word)) {
        return 'real number';
    } elseif (ctype_digit($word) && (int)$word > 0) {
        return 'positive integer';
    } else {
        return 'undefined type';
    }
}

$input_phrase = isset($_POST['phrase']) ? trim($_POST['phrase']) : '';
$requested_type = isset($_GET['type']) ? $_GET['type'] : '';
$words = explode(' ', $input_phrase);

echo "<table border='1'>
        <tr>
            <th> Word </th>
            <th> Length </th>
            <th> Type </th>
        </tr>";

foreach ($words as $word) {
    $word_type = determine_type_of_word($word);

    if ($requested_type === $word_type) {
        echo "<tr>
                <td> $word </td>
                <td> " . strlen($word) . " </td>
                <td> $word_type </td>
              </tr>";
    }
}

echo "</table><br>";
?>

<p><a href = "PhraseInput.html"> Go back to the Phrase Input page </a></p>

</body>
</html>
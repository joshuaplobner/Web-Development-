http://localhost/plobnej_170_a2/a2part1/PhraseInput.html
http://localhost/plobnej_170_a2/a2part2/PhraseInput.html
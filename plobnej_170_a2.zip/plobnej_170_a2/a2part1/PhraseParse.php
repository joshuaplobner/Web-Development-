<!DOCTYPE html>
<html>
<head>
    <title> PhraseParse </title>
</head>
<body>
<?php
function determine_type_of_word($word) {
    $has_only_alphabetic_characters = true;
    $word = str_replace(' ', '', $word); 
    
    for ($i = 0; $i < strlen($word); $i++) {
        $char = $word[$i];
        if (!(($char >= 'a' && $char <= 'z') || ($char >= 'A' && $char <= 'Z'))) {
            $has_only_alphabetic_characters = false;
            break;
        }
    }

    if ($has_only_alphabetic_characters) {
        return 'alphabetic characters'; 
    } elseif (strpos($word, '.') !== false && is_numeric($word)) {
        return 'real number';
    } elseif (ctype_digit($word) && (int)$word > 0) {
        return 'positive integer';
    } else {
        return 'undefined type';
    }
}

$input_phrase = isset($_POST['phrase']) ? trim($_POST['phrase']) : '';
$words = explode(' ', $input_phrase);
$word_count = count($words);
$has_a_real_number = false;

if (!empty($input_phrase)) {
    if ($word_count < 3) {
        echo "<p> Error: The phrase must have at least 3 words. </p>";
        echo "<p><a href='PhraseInput.html'> Go back to the page </a></p>";
        exit();
    }

    echo "<table border='1'>
                <tr>
                    <th> Word </th>
                    <th> Length </th>
                    <th> Type </th>
                </tr>";

    foreach ($words as $word) {
        if (empty($word)) {
            echo "<p> Error: The phrase cannot have empty words. </p>";
            echo "<p><a href='PhraseInput.html'> Go back to the page </a></p>";
            exit();
        }

        $word_type = determine_type_of_word($word);

        if ($word_type === 'real number') {
            $has_a_real_number = true;
        }

        echo "<tr>
                    <td> $word </td>
                    <td> " . strlen($word) . " </td>
                    <td> $word_type </td>
              </tr>";
    }

    echo "</table><br>";

    if ($has_a_real_number) {
        echo "<p> Your phrase parsed into words. </p>";
    } else {
        echo "<p> Error: The phrase must have at least one real number (WT2). </p>";
        echo "<p><a href='PhraseInput.html'> Go back to the page </a></p>";
    }
} else {
    echo "<p> Error: Invalid form submission. </p>";
    echo "<p><a href='PhraseInput.html'> Go back to the page </a></p>";
}
?>
</body>
</html>
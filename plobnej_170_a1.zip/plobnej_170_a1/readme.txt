The files that I have submitted are: 
- Page1.html
- Page2.html 
- Page2.css
- Page3.css 
- Stream.jpg
- Train.jpg

Page1.html is a webpage that allows the user to enter their first and last name respectively then submit their entries to view a hidden field that displays on the screen with their entry. 
Page2.css is an external CSS file that adds styles to the Submit and Help button in Page1.html. 
Page2.html is a webpage that displays information on a book formatted in a table based on the middle digit of the student's student number modulus 4 answer. 
Page3.css is an external CSS file that adds styles to five different XHTML tags and two custom styles in Page2.html. 
Stream.jpg is an image of a stream that has been added into the Page2.html file. 
Train.jpg is an image of a train that has been added into the Page2.html file. 

For the first webpage (Page1.html) the customizations I made are:
- Adding an <h1> tag explaining that the webpage is using a table inside a form.  
- Adding a blue background colour to the Submit and Help buttons. 
- Aligning the text in the center on the buttons.
- Making the size of the font 15px on the buttons.
- Using Arial for the type of font on the buttons. 
- In the first webpage the Javascript code I wrote will simulate the submit button allowing a pop up field to be displayed with a hidden value. This was accomplished with the help of document.getElementById. 

For the second webpage (Page2.html) the customizations I made are:
- Adding a stream and train image into the webpage of my choice. 
- Button1, Button2, Button3 have different colours and font styles. 
- Changing the styles of five XHTML tags specifically <i> tag making the colour green. I made the <label> tag red. I made the <table> tag light gray and the border solid black 1px. I made <td> tag light gray and the border solid black 1px. Finally, I made the <body> tag light blue.  
- I wrote Javascript code to simulate the submit button to show the value of the hidden field. I also made pop up windows for the radio buttons, check boxes, drop down menu, and input text.  